import discord
from discord.ext import commands
from discord import app_commands
import json
import os
import random
from datetime import datetime

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="/", intents=intents)
tree = bot.tree

BANK_FILE = "bank.json"
QUEST_FILE = "quests.json"
ACHIEVEMENTS_FILE = "achievements.json"

# ---------- Load/Save Functions ----------

def load_bank():
    if os.path.exists(BANK_FILE):
        with open(BANK_FILE, "r") as f:
            return json.load(f).get("copper", 0)
    return 0

def save_bank(copper):
    with open(BANK_FILE, "w") as f:
        json.dump({"copper": copper}, f)

def load_quests():
    if os.path.exists(QUEST_FILE):
        with open(QUEST_FILE, "r") as f:
            return json.load(f)
    return {"active": {}, "completed": {}}

def save_quests(data):
    with open(QUEST_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load_achievements():
    if os.path.exists(ACHIEVEMENTS_FILE):
        with open(ACHIEVEMENTS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_achievements(data):
    with open(ACHIEVEMENTS_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ---------- Initialize Data ----------

bank_copper = load_bank()
quests = load_quests()
achievements = load_achievements()

def format_currency(copper: int) -> str:
    gold = copper // 1000
    silver = (copper % 1000) // 100
    copper = copper % 100
    return f"{gold} gold, {silver} silver, {copper} copper"

# ---------- Bank Commands with Note Option ----------

@tree.command(name="bank", description="Add, remove, or clear money from the tavern bank")
@app_commands.describe(
    action="Choose to add, remove, or clear money",
    gold="Gold amount",
    silver="Silver amount",
    copper="Copper amount",
    note="Optional note for the transaction"
)
@app_commands.choices(action=[
    app_commands.Choice(name="add", value="add"),
    app_commands.Choice(name="remove", value="remove"),
    app_commands.Choice(name="clear", value="clear")
])
async def bank_command(interaction: discord.Interaction, action: app_commands.Choice[str], gold: int = 0, silver: int = 0, copper: int = 0, note: str = None):
    global bank_copper
    total_copper = gold * 1000 + silver * 100 + copper * 1

    if action.value == "add":
        bank_copper += total_copper
        save_bank(bank_copper)
        msg = f"\U0001F4B0 Added {format_currency(total_copper)}\n\U0001F3E6 Total: {format_currency(bank_copper)}"
        if note:
            msg += f"\n**Note:** {note}"
    
    elif action.value == "remove":
        if total_copper > bank_copper:
            msg = "❌ Not enough funds!"
        else:
            bank_copper -= total_copper
            save_bank(bank_copper)
            msg = f"\U0001F4B8 Removed {format_currency(total_copper)}\n\U0001F3E6 Total: {format_currency(bank_copper)}"
            if note:
                msg += f"\n**Note:** {note}"
    
    elif action.value == "clear":
        bank_copper = 0
        save_bank(bank_copper)
        msg = "❌ The bank has been cleared. All funds are gone."

    embed = discord.Embed(title="Tavern Bank Update", description=msg, color=discord.Color.gold())
    await interaction.response.send_message(embed=embed)

@tree.command(name="balance", description="Show current tavern balance")
async def balance(interaction: discord.Interaction):
    embed = discord.Embed(title="\U0001F3E6 Tavern Balance", description=format_currency(bank_copper), color=discord.Color.teal())
    await interaction.response.send_message(embed=embed)

# ---------- Expenses Command ----------

@tree.command(name="expenses", description="Spend random copper for tavern expenses")
async def expenses(interaction: discord.Interaction):
    global bank_copper

    reasons = [
        "Replaced broken mugs 🍺",
        "Bought new dice for the gambling table 🎲",
        "Bribed the local guard to look the other way 🪙",
        "Hired a bard for evening entertainment 🎵",
        "Paid for spilled drinks cleanup 🧽",
        "Restocked the pantry with stew meat 🥩",
        "Repaired a leaky keg 🍻",
        "Tipped the kitchen staff generously 🤅"
    ]

    expense = random.randint(50, min(2000, bank_copper)) if bank_copper > 0 else 0

    if expense == 0:
        await interaction.response.send_message("❌ Not enough funds to cover tavern expenses!")
        return

    bank_copper -= expense
    save_bank(bank_copper)
    reason = random.choice(reasons)

    embed = discord.Embed(
        title="🍻 Tavern Expenses Paid",
        description=f"**{reason}**\n\U0001F4B8 Deducted: {format_currency(expense)}\n\U0001F3E6 New Balance: {format_currency(bank_copper)}",
        color=discord.Color.dark_gold()
    )
    embed.set_footer(text=f"Requested by {interaction.user.display_name}")
    await interaction.response.send_message(embed=embed)

# ---------- Achievement Commands ----------

@tree.command(name="achievement", description="Add, remove, or list achievements")
@app_commands.describe(
    action="Choose an action: add, remove, or list",
    achievement_name="Name of the achievement (for add/remove)",
    description="Description (required for add)"
)
@app_commands.choices(action=[
    app_commands.Choice(name="add", value="add"),
    app_commands.Choice(name="remove", value="remove"),
    app_commands.Choice(name="list", value="list")
])
async def achievement(interaction: discord.Interaction, action: app_commands.Choice[str], achievement_name: str = None, description: str = None):
    global achievements

    if action.value == "add":
        if not achievement_name or not description:
            await interaction.response.send_message("Please provide both name and description.")
            return
        date = datetime.now().strftime("%d-%m-%Y")
        achievements[achievement_name] = {"description": description, "date": date}
        save_achievements(achievements)

        embed = discord.Embed(
            title=f"🏆 Achievement Unlocked: {achievement_name}",
            description=f"{description}\n🗕️ **Date:** {date}",
            color=discord.Color.green()
        )
        embed.add_field(name="⭐", value=f"**{achievement_name}**", inline=False)
        await interaction.response.send_message(embed=embed)

    elif action.value == "remove":
        if not achievement_name:
            await interaction.response.send_message("Please provide the achievement name to remove.")
            return
        if achievement_name not in achievements:
            await interaction.response.send_message(f"❌ Achievement '{achievement_name}' not found.")
            return
        achievements.pop(achievement_name)
        save_achievements(achievements)
        await interaction.response.send_message(f"🗑️ Achievement '{achievement_name}' removed.")

    elif action.value == "list":
        if not achievements:
            await interaction.response.send_message("No achievements added yet.")
            return

        embed = discord.Embed(title="🌟 Achievements", color=discord.Color.blue())
        for name, data in achievements.items():
            embed.add_field(
                name=f"⭐ {name}",
                value=f"{data['description']}\n🗕️ **Date:** {data['date']}",
                inline=False
            )
        await interaction.response.send_message(embed=embed)

# ---------- Quest Commands ----------

@tree.command(name="quest", description="Add, complete, or list quests")
@app_commands.describe(
    action="Choose to add, complete, or list quests",
    quest_name="Name of the quest",
    description="Description for new quests"
)
@app_commands.choices(action=[
    app_commands.Choice(name="add", value="add"),
    app_commands.Choice(name="complete", value="complete"),
    app_commands.Choice(name="list", value="list")
])
async def quest(interaction: discord.Interaction, action: app_commands.Choice[str], quest_name: str = None, description: str = None):
    global quests

    if action.value == "add":
        if not quest_name or not description:
            await interaction.response.send_message("Please provide both quest name and description.")
            return
        quests["active"][quest_name] = description
        save_quests(quests)

        embed = discord.Embed(
            title="📜 Quest Added",
            description=f"**{quest_name}**\n{description}",
            color=discord.Color.purple()
        )
        await interaction.response.send_message(embed=embed)

    elif action.value == "complete":
        if not quest_name:
            await interaction.response.send_message("Please provide the quest name to complete.")
            return
        if quest_name not in quests["active"]:
            await interaction.response.send_message(f"❌ Quest '{quest_name}' not found in active quests.")
            return
        quests["completed"][quest_name] = quests["active"].pop(quest_name)
        save_quests(quests)

        embed = discord.Embed(
            title="✅ Quest Completed",
            description=f"**{quest_name}**\n{quests['completed'][quest_name]}",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)

    elif action.value == "list":
        embed = discord.Embed(title="📜 Quest Log", color=discord.Color.orange())

        if quests["active"]:
            active_list = "\n\n".join([f"🟡 **{q}**: {d}" for q, d in quests["active"].items()])
            embed.add_field(name="Active Quests", value=active_list, inline=False)
        else:
            embed.add_field(name="Active Quests", value="None", inline=False)

        if quests["completed"]:
            completed_list = "\n\n".join([f"🟢 **{q}**: {d}" for q, d in quests["completed"].items()])
            embed.add_field(name="Completed Quests", value=completed_list, inline=False)
        else:
            embed.add_field(name="Completed Quests", value="None", inline=False)

        await interaction.response.send_message(embed=embed)

# ---------- Bot Ready ----------

@bot.event
async def on_ready():
    await tree.sync()
    print(f"Bot is online as {bot.user}!")

bot.run("MTM2ODY5NjQyMzg1MTIzMzMwMA.Gj9u59.x4QhHfwYlcq5k65Ygdcr5VTOy9HoOV_wJ121ZY")  # Replace with your bot token
